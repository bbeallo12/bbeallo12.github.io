# FairChess
We love chess, but is it fair?

With this twist on regular chess, Fair Chess implements the [fairest sharing sequence](https://youtu.be/prh72BLNjIk)" for the turn order.

Check out the projects we used!
* [chessboard.js](https://github.com/oakmac/chessboardjs/)
* [jQuery](https://jquery.com)
